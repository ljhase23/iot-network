package org.ws4d.coap.server;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;
import org.ws4d.coap.connection.BasicCoapClientChannel;
import org.ws4d.coap.connection.BasicCoapServerChannel;
import org.ws4d.coap.connection.BasicCoapSocketHandler;
import org.ws4d.coap.interfaces.CoapChannel;
import org.ws4d.coap.interfaces.CoapClient;
import org.ws4d.coap.interfaces.CoapClientChannel;
import org.ws4d.coap.interfaces.CoapResponse;
import org.ws4d.coap.messages.CoapMediaType;
import org.ws4d.coap.rest.BasicCoapResource;
import org.ws4d.coap.rest.CoapResourceServer;
import org.ws4d.coap.rest.ResourceHandler;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.UnknownHostException;
import java.util.Enumeration;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * @author Christian Lerche <christian.lerche@uni-rostock.de>
 * 
 */
public class CoapSampleResourceServer extends JFrame implements CoapClient, ActionListener
{

	private static CoapSampleResourceServer sampleServer;
	private CoapResourceServer resourceServer;
	private static Logger logger = Logger
			.getLogger(CoapSampleResourceServer.class.getName());
	
	//UI
	private JTextField uriField;
	private JTextField payloadField;
	private JButton postBtn, getBtn;
	private JTextArea area;

	/**
	 * @param args
	 * @throws IOException 
	 */
	public void clientUi()
	{
		setTitle("CoAP Server");
		setSize(800,380);
		setLocation(400,300);
		setLayout(null);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JLabel label = new JLabel("Thermister");
		label.setBounds(10, 20, 100, 30);
		label.setFont(new Font("Serif", Font.PLAIN, 15));
		add(label);

		uriField = new JTextField();
		uriField.setBounds(100, 20, 150, 30);
		uriField.setFont(new Font("Serif", Font.PLAIN, 15));
		add(uriField);

		label = new JLabel("Payload");
		label.setBounds(10, 70, 100, 30);
		label.setFont(new Font("Serif", Font.PLAIN, 15));
		add(label);

		payloadField = new JTextField();
		payloadField.setBounds(100, 70, 150, 30);
		payloadField.setFont(new Font("Serif", Font.PLAIN, 15));
		add(payloadField);

		getBtn = new JButton("GET");
		getBtn.setBounds(30, 130, 100, 30);
		getBtn.setFont(new Font("Serif", Font.PLAIN, 15));
		getBtn.addActionListener(this);
		add(getBtn);

		postBtn = new JButton("POST");
		postBtn.setBounds(140, 130, 100, 30);
		postBtn.setFont(new Font("Serif", Font.PLAIN, 15));
		postBtn.addActionListener(this);
		add(postBtn);

		area = new JTextArea();
		area.setFont(new Font("Serif", Font.PLAIN, 15));
		JScrollPane sc = new JScrollPane(area);
		sc.setBounds(270, 20, 500, 300);
		add(sc);

		setVisible(false);
	}
	
	public static void main(String[] args) throws IOException {
        logger.addAppender(new ConsoleAppender(new SimpleLayout()));
		logger.setLevel(Level.INFO);
		logger.info("Start Sample Resource Server");
		sampleServer = new CoapSampleResourceServer();
		
		//UI
		sampleServer.clientUi();
		
		sampleServer.run();
		
	}
	
	private void run() throws IOException 
	{
		if (resourceServer != null)
			resourceServer.stop();
		resourceServer = new CoapResourceServer();
		
		/* Show detailed logging of Resource Server*/
		Logger resourceLogger = Logger.getLogger(CoapResourceServer.class.getName());
		resourceLogger.setLevel(Level.ALL);
		
		/* add resources */
		BasicCoapResource light = new BasicCoapResource("/test/light", "light Actuator".getBytes(), CoapMediaType.text_plain);
		light.registerResourceHandler(new ResourceHandler() {
			@Override
			public void onPost(byte[] data) {
				System.out.println("Post to /test/light");
				light.setValue(data);
				light.changed();
				
				/*String inputData = new String (data);
				if(inputData.equals("redOn")) {
					
				}else if(inputData.equals("redOff")) {
					
				}else
				if(inputData.equals("greenOn")) {
					
				}else if(inputData.equals("greenOff")) {
					
				}else
				if(inputData.equals("blueOn")) {

				}else if(inputData.equals("blueOff")) {
					
				}else
				if(inputData.equals("allOn")) {
					
				}else if(inputData.equals("allOff")) {
					
				}*/
				
			}
		});
		light.setObservable(false);
		resourceServer.createResource(light);
		try {
			resourceServer.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//observe example
		
		/*
		int counter = 0;
		while(true){
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			counter++;
			light.setValue(((String)"Message #" + counter).getBytes());
			light.changed();
		}*/
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onResponse(CoapClientChannel channel, CoapResponse response) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMCResponse(CoapClientChannel channel, CoapResponse response, InetAddress srcAddress, int srcPort) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onConnectionFailed(CoapClientChannel channel, boolean notReachable, boolean resetByServer) {
		// TODO Auto-generated method stub
		
	}
}
