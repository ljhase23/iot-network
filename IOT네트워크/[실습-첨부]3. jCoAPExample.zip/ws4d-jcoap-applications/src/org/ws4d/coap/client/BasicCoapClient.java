package org.ws4d.coap.client;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.server.ServerCloneException;
import java.util.Random;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.ws4d.coap.Constants;
import org.ws4d.coap.connection.BasicCoapChannelManager;
import org.ws4d.coap.connection.BasicCoapClientChannel;
import org.ws4d.coap.interfaces.CoapChannelManager;
import org.ws4d.coap.interfaces.CoapClient;
import org.ws4d.coap.interfaces.CoapClientChannel;
import org.ws4d.coap.interfaces.CoapRequest;
import org.ws4d.coap.interfaces.CoapResponse;
import org.ws4d.coap.messages.CoapBlockOption;
import org.ws4d.coap.messages.CoapBlockOption.CoapBlockSize;
import org.ws4d.coap.messages.CoapMediaType;
import org.ws4d.coap.messages.CoapRequestCode;

/**
 * @author	Christian Lerche <christian.lerche@uni-rostock.de>
 * 			Bjoern Konieczek <bjoern.konieczek@uni-rostock.de>
 */
public class BasicCoapClient extends JFrame implements CoapClient
{
	private String SERVER_ADDRESS;
	private int PORT; 

	static int counter = 0;
	private CoapChannelManager channelManager = null;
	private BasicCoapClientChannel clientChannel = null;
	private Random tokenGen = null;


	//UI �������� ����
	


	public BasicCoapClient(String server_addr, int port ){//������
		super();
		this.SERVER_ADDRESS = server_addr;
		this.PORT = port;
		this.channelManager = BasicCoapChannelManager.getInstance();
		this.tokenGen = new Random();



	}
	public boolean connect(){
		try {
			clientChannel = (BasicCoapClientChannel) channelManager.connect(this, InetAddress.getByName(SERVER_ADDRESS), PORT);
		} catch( UnknownHostException e ){
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean connect( String server_addr, int port ){
		this.SERVER_ADDRESS = server_addr;
		this.PORT = port;
		return this.connect();
	}


	public CoapRequest createRequest( boolean reliable, CoapRequestCode reqCode ) {
		return clientChannel.createRequest( reliable, reqCode );
	}

	public byte[] generateRequestToken(int tokenLength ){
		byte[] token = new byte[tokenLength];
		tokenGen.nextBytes(token);
		return token;
	}

	@Override
	public void onConnectionFailed(CoapClientChannel channel, boolean notReachable, boolean resetByServer) {
		System.out.println("Connection Failed");
	}

	@Override
	public void onResponse(CoapClientChannel channel, CoapResponse response) {
		System.out.println("Received response");
		if(response.getPayload() != null)
		{
			String responseData = new String(response.getPayload()); 
			System.out.println(responseData);
		}else
		{
			System.out.println("response payload null");
			
		}
	}

	@Override
	public void onMCResponse(CoapClientChannel channel, CoapResponse response, InetAddress srcAddress, int srcPort) {
		System.out.println("MCReceived response");
	}

	public void resourceDiscoveryExample()
	{
		try {
			clientChannel = (BasicCoapClientChannel) channelManager.connect(this, InetAddress.getByName(SERVER_ADDRESS), PORT);
			CoapRequest coapRequest = clientChannel.createRequest(true, CoapRequestCode.GET);
			byte [] token = generateRequestToken(3);
			coapRequest.setUriPath("/.well-known/core");
			coapRequest.setToken(token);
			clientChannel.sendMessage(coapRequest);
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	public void postExample()
	{
		try {
			clientChannel = (BasicCoapClientChannel) channelManager.connect(this, InetAddress.getByName(SERVER_ADDRESS), PORT);
			CoapRequest coapRequest = clientChannel.createRequest(true, CoapRequestCode.POST);
			byte [] token = generateRequestToken(3);
			coapRequest.setUriPath("/test/light");
			coapRequest.setToken(token);
			coapRequest.setPayload("lightTest".getBytes());
			clientChannel.sendMessage(coapRequest);
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	public void getExample()
	{
		try {
			clientChannel = (BasicCoapClientChannel) channelManager.connect(this, InetAddress.getByName(SERVER_ADDRESS), PORT);
			CoapRequest coapRequest = clientChannel.createRequest(true, CoapRequestCode.GET);
			byte [] token = generateRequestToken(3);
			coapRequest.setUriPath("/test/light");
			coapRequest.setToken(token);
			clientChannel.sendMessage(coapRequest);
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	public void observeExample()
	{
		try {
			clientChannel = (BasicCoapClientChannel) channelManager.connect(this, InetAddress.getByName(SERVER_ADDRESS), PORT);
			CoapRequest coapRequest = clientChannel.createRequest(true, CoapRequestCode.GET);
			byte [] token = generateRequestToken(3);
			coapRequest.setUriPath("/test/light");
			coapRequest.setToken(token);
			coapRequest.setObserveOption(1);
			clientChannel.sendMessage(coapRequest);
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	//client Ui
	public void clientUi()
	{
		//Swing ������Ʈ�� ����� GUI ����
	}

	

	public static void main(String[] args)
	{
		System.out.println("Start CoAP Client");
		String serverIp = "127.0.0.1";
		//Constants.COAP_DEFAULT_PORT (5683)
		BasicCoapClient client = new BasicCoapClient(serverIp, Constants.COAP_DEFAULT_PORT);
		client.channelManager = BasicCoapChannelManager.getInstance();
		
		//clientUi() ȣ��
		

		//example
		client.resourceDiscoveryExample();
		//client.getExample();
		//client.postExample();
		//client.observeExample();
	}



}
